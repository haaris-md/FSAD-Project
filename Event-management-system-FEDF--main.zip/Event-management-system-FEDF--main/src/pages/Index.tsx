import Hero from "@/components/Hero";

const Index = () => {
  return <Hero />;
};

export default Index;
